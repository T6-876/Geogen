# GD Auto Level Generator

A simple mod for Geometry Dash built with the Geode SDK that automatically generates a basic level layout when opening the editor.

## Features

- Procedural platform generation
- Random spike placement
- Easy starting template for generator mods

## Requirements

- Geode SDK
- CMake
- Geometry Dash

## Build

```bash
cmake -B build
cmake --build build
```

## Install

Place the compiled `.geode` file into your Geode mods folder.