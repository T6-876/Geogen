#include <Geode/Geode.hpp>
#include <Geode/modify/EditorLayer.hpp>

using namespace geode::prelude;

// Simple procedural generator example
class $modify(AutoGenEditor, EditorLayer) {

    bool init(LevelEditorLayer* editor) {
        if (!EditorLayer::init(editor)) return false;

        generateLevel();

        return true;
    }

    void generateLevel() {
        float x = 0.0f;

        // Generate simple platform layout
        for (int i = 0; i < 150; i++) {
            auto block = GameObject::createWithKey(1);
            block->setPosition({x, 120});

            this->addObject(block);

            // randomly add spikes
            if (rand() % 4 == 0) {
                auto spike = GameObject::createWithKey(8);
                spike->setPosition({x, 150});
                this->addObject(spike);
            }

            x += 30.0f;
        }
    }
};